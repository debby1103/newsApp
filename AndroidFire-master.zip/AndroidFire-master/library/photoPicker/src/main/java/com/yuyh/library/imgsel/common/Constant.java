package com.yuyh.library.imgsel.common;

import com.yuyh.library.imgsel.ImgSelConfig;

import java.util.ArrayList;

/**
 * @author yuyh.
 * @date 2016/8/5.
 */
public class Constant {

    public static ImgSelConfig config;

    public static int screenWidth = 0;

    public static ArrayList<String> imageList = new ArrayList<>();

}
