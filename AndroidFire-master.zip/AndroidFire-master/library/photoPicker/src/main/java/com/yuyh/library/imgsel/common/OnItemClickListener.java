package com.yuyh.library.imgsel.common;

import com.yuyh.library.imgsel.bean.Image;

/**
 * @author yuyh.
 * @date 2016/8/5.
 */
public interface OnItemClickListener {

    void onClick(int position, Image image);
}
