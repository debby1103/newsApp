package com.wevey.selector.dialog;

import android.widget.Button;

/**
 * Created by weavey
 * on 2016-09-05.
 * todo
 */
public interface DialogOnItemClickListener {

    void onItemClick(Button button, int position);
}
