package com.jaydenxiao.common.alipay;

/**
 * des:支付返回结果
 * Created by xsf
 * on 2016.04.19:22
 */
public interface PayCallback {

    void payResult(String result);
}
