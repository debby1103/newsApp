package com.jaydenxiao.androidfire.ui.zone.spannable;

/**
 * des:
 * Created by xsf
 * on 2016.07.11:14
 */
public interface ISpanClick {
    public void onClick(int position);
}
